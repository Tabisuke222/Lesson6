# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '422b02aec423d11f2f1064827f71b6b3a8d4112bc55ed53ebf081c5415f50d016c66cc8ea4f411dd84e7c460c4f8113bb3411320bb2ebc2050c3bfe3220d8108'